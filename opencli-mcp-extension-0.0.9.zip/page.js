"use strict";
(() => {
  // src/shared/page-contract.ts
  var ENGINE_GLOBAL = "__opencliInjected";
  var PAGE_GLOBAL = "__opencliPage";
  var ACT_MARK = "data-opencli-act";
  var FRAME_MARK = "data-opencli-frame";

  // extension/src/page/index.ts
  function injected() {
    const i = globalThis[ENGINE_GLOBAL];
    if (!i) throw new Error("engine_missing");
    return i;
  }
  function query(selector, root = document) {
    const rm = /^aria-ref=(e\d+)$/.exec(selector);
    if (rm) {
      const el = refToEl.get(rm[1]);
      return el && el.isConnected ? [el] : [];
    }
    const i = injected();
    return i.querySelectorAll(i.parseSelector(selector), root);
  }
  function stateOf(el, name) {
    try {
      const r = injected().elementState(el, name);
      return { matches: r.matches === true, received: String(r.received ?? "") };
    } catch (e) {
      return { matches: false, received: "error:" + (e?.message || String(e)) };
    }
  }
  var is = (el, name) => stateOf(el, name).matches;
  function box(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) };
  }
  var text = (el) => (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  function replaySelector(el) {
    try {
      return injected().generateSelector(el, { testIdAttributeName: "data-testid" }).selector;
    } catch {
      return null;
    }
  }
  function roleOf(el) {
    try {
      const u = injected().utils;
      return u?.getAriaRole && u.getAriaRole(el) || el.getAttribute("role") || "";
    } catch {
      return el.getAttribute("role") || "";
    }
  }
  function nameOf(el) {
    try {
      const u = injected().utils;
      return u?.getElementAccessibleNameText ? String(u.getElementAccessibleNameText(el, false) || "") : "";
    } catch {
      return "";
    }
  }
  function lastSnapshot() {
    try {
      return injected()._lastAriaSnapshotForQuery ?? null;
    } catch {
      return null;
    }
  }
  var refEngine = null;
  var stableId = /* @__PURE__ */ new WeakMap();
  var nextStableId = 1;
  var refToEl = /* @__PURE__ */ new Map();
  function resetRefsIfEngineChanged() {
    let e = null;
    try {
      e = injected();
    } catch {
      e = null;
    }
    if (e !== refEngine) {
      refEngine = e;
      stableId = /* @__PURE__ */ new WeakMap();
      nextStableId = 1;
      refToEl.clear();
    }
  }
  function stableRefOf(el) {
    let id = stableId.get(el);
    if (id === void 0) {
      id = nextStableId++;
      stableId.set(el, id);
    }
    const ref = "e" + id;
    refToEl.set(ref, el);
    if (refToEl.size > 4e3) {
      for (const [k, v] of refToEl) if (!v.isConnected) refToEl.delete(k);
      if (refToEl.size > 6e3) {
        let drop = refToEl.size - 4e3;
        for (const k of refToEl.keys()) {
          if (drop-- <= 0) break;
          refToEl.delete(k);
        }
      }
    }
    return ref;
  }
  function ariaRefOf(el) {
    resetRefsIfEngineChanged();
    return stableRefOf(el);
  }
  var candidate = (el) => ({ tag: el.tagName.toLowerCase(), role: el.getAttribute("role") || "", text: text(el).slice(0, 80), ref: ariaRefOf(el), visible: is(el, "visible"), box: box(el) });
  var actEl = () => document.querySelector(`[${ACT_MARK}]`);
  function markAct(el) {
    document.querySelectorAll(`[${ACT_MARK}]`).forEach((n) => n.removeAttribute(ACT_MARK));
    el.setAttribute(ACT_MARK, "1");
  }
  function clearActMark() {
    document.querySelectorAll(`[${ACT_MARK}]`).forEach((n) => n.removeAttribute(ACT_MARK));
  }
  var ALIGN_BLOCKS = /* @__PURE__ */ new Set(["start", "center", "end", "nearest"]);
  async function resolve(args) {
    const { selector, fallback, strict, states, align } = args;
    let usedSelector = selector;
    let matches = query(selector);
    if (!matches.length && fallback) {
      usedSelector = fallback;
      matches = query(fallback);
    }
    if (!matches.length) return { error: { code: "not_found", message: `no element matches ${selector}` }, retry: true };
    let el = matches[0];
    if (matches.length > 1 && strict) {
      const visible = matches.filter((m) => is(m, "visible"));
      if (visible.length === 1) el = visible[0];
      else return { error: { code: "selector_ambiguous", message: `${matches.length} elements match ${selector}${visible.length ? ` (${visible.length} visible)` : ""}`, hint: "Add nth, use a more specific locator, or act on a ref/selector from find.", candidates: matches.slice(0, 8).map(candidate) }, retry: false };
    }
    for (const st of states) {
      const r = stateOf(el, st);
      if (r.received === "error:notconnected") return { error: { code: "stale_ref", message: "element detached during resolution" }, retry: true };
      if (!r.matches) return { error: { code: st === "visible" ? "not_visible" : st === "enabled" ? "not_enabled" : "not_editable", message: `element is not ${st}${r.received.startsWith("error:") ? ` (${r.received.slice(6)})` : ""}`, candidates: [candidate(el)] }, retry: true };
    }
    try {
      el.scrollIntoView({ block: ALIGN_BLOCKS.has(align.block) ? align.block : "center", inline: ALIGN_BLOCKS.has(align.inline) ? align.inline : "nearest", behavior: "instant" });
    } catch {
    }
    let prev = null;
    let stable = 0;
    const t0 = performance.now();
    for (; ; ) {
      const r = el.getBoundingClientRect();
      const cur = [r.left, r.top, r.width, r.height].map(Math.round).join(",");
      stable = prev === cur ? stable + 1 : 0;
      prev = cur;
      if (stable >= 1 || performance.now() - t0 > 700) break;
      await new Promise((res) => setTimeout(res, 40));
    }
    for (const st of states) if (!is(el, st)) return { error: { code: `not_${st}`, message: `element is not ${st} after scrolling` }, retry: true };
    const b = el.getBoundingClientRect();
    if (b.width <= 0 || b.height <= 0) return { error: { code: "not_visible", message: "element has no clickable box" }, retry: true };
    const x = Math.max(0, b.left + b.width / 2), y = Math.max(0, b.top + b.height / 2);
    if (x > innerWidth || y > innerHeight) return { error: { code: "not_visible", message: "element is outside the viewport" }, retry: true };
    const tag = el.tagName.toLowerCase();
    const type = el.type;
    const checkable = tag === "input" && (type === "checkbox" || type === "radio") || ["checkbox", "radio", "switch"].includes(el.getAttribute("role") || "");
    const hit = injected().expectHitTarget({ x, y }, el);
    markAct(el);
    return {
      ok: true,
      x,
      y,
      matches_n: matches.length,
      tag,
      hit: hit === "done" ? "target" : "other",
      blocker: hit === "done" ? null : hit && hit.hitTargetDescription || "another element",
      editable: is(el, "editable"),
      checkable,
      checked: checkable ? is(el, "checked") : false,
      isSelect: tag === "select",
      ref: ariaRefOf(el),
      selector: replaySelector(el),
      usedSelector
    };
  }
  function pointInfo(args) {
    const el = document.elementFromPoint(args.x, args.y);
    if (!el) return null;
    markAct(el);
    const tag = el.tagName.toLowerCase();
    const editable = Boolean(el.isContentEditable || (tag === "input" || tag === "textarea") && !el.readOnly && !el.disabled);
    return { tag, editable, isSelect: tag === "select" };
  }
  var retarget = (el) => injected().retarget(el, "follow-label") || el;
  function focus() {
    const el = actEl();
    if (!el) return "error:notconnected";
    return String(injected().focusNode(retarget(el), false));
  }
  function readValue() {
    const el = actEl();
    if (!el) return null;
    const t = retarget(el);
    return t.isContentEditable ? t.textContent ?? "" : t.value ?? null;
  }
  function fill(args) {
    const el = actEl();
    if (!el) return "error:notconnected";
    try {
      return String(injected().fill(el, args.value));
    } catch (e) {
      return "error:" + (e?.message || String(e));
    }
  }
  function nativeSet(args) {
    const el = actEl();
    if (!el) return false;
    const t = retarget(el);
    if (t.isContentEditable) {
      t.textContent = args.value;
    } else {
      const proto = t.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const set = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (set) set.call(t, args.value);
      else t.value = args.value;
    }
    t.dispatchEvent(new Event("input", { bubbles: true }));
    t.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  function isChecked() {
    const el = actEl();
    if (!el) return null;
    const r = stateOf(el, "checked");
    return r.received.startsWith("error:") ? null : r.matches;
  }
  function select(args) {
    const el = actEl();
    if (!el) return { error: "gone" };
    const i = injected();
    let r = i.selectOptions(el, [{ valueOrLabel: args.value }]);
    if (r === "error:optionsnotfound" && /^\d+$/.test(args.value)) r = i.selectOptions(el, [{ index: Number(args.value) }]);
    if (typeof r === "string" && r.startsWith("error:")) {
      const available = [...el.options ?? []].map((o) => o.label || o.value).slice(0, 50);
      return { error: r.slice(6), available };
    }
    return { selected: Array.isArray(r) ? r.map(String) : [] };
  }
  function caretToEnd() {
    const el = document.activeElement;
    if (el && !el.isContentEditable && typeof el.setSelectionRange === "function") {
      try {
        const n = el.value.length;
        el.setSelectionRange(n, n);
      } catch {
      }
    }
  }
  function isFileInput() {
    const el = actEl();
    return !!el && el.tagName === "INPUT" && el.type === "file";
  }
  function useAssociatedFileInput() {
    const el = actEl();
    if (!el) return false;
    const control = el.control;
    const inp = el.querySelector("input[type=file]") || (control && control.type === "file" ? control : null) || (el.closest("form,body") || document.body).querySelector("input[type=file]");
    if (!inp) return false;
    markAct(inp);
    return true;
  }
  function settle(args) {
    return new Promise((resolveP) => {
      const t0 = performance.now();
      let timer;
      const finish = (quiet) => {
        obs.disconnect();
        clearTimeout(cap);
        resolveP({ waitedMs: Math.round(performance.now() - t0), quiet });
      };
      const arm = () => {
        clearTimeout(timer);
        timer = setTimeout(() => finish(true), args.quietMs);
      };
      const obs = new MutationObserver(arm);
      obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      const cap = setTimeout(() => {
        clearTimeout(timer);
        finish(false);
      }, args.maxMs);
      arm();
    });
  }
  function frameProbe(args) {
    document.querySelectorAll(`[${FRAME_MARK}]`).forEach((n) => n.removeAttribute(FRAME_MARK));
    const list = typeof args.step === "number" ? [...document.querySelectorAll("iframe,frame")] : query(args.step);
    const fe = typeof args.step === "number" ? list[args.step] : list[0];
    if (!fe) return { found: false };
    let sameOrigin = false;
    try {
      sameOrigin = Boolean(fe.contentWindow && fe.contentWindow.document);
    } catch {
      sameOrigin = false;
    }
    try {
      fe.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
    } catch {
    }
    fe.setAttribute(FRAME_MARK, "1");
    const r = fe.getBoundingClientRect();
    return { found: true, sameOrigin, x: r.left + fe.clientLeft, y: r.top + fe.clientTop, src: fe.src || "" };
  }
  function clearFrameMark() {
    document.querySelectorAll(`[${FRAME_MARK}]`).forEach((n) => n.removeAttribute(FRAME_MARK));
  }
  var CRED = /user[-_ ]?name|e[-_ ]?mail|one[-_ ]?time[-_ ]?code|password|passcode|passwd|\botp\b|\b(?:2fa|mfa)\b|phone|mobile|\btel\b|\bcc-|cvc|cvv|csc|card|credit|payment|security[-_ ]?code|\biban\b|account[-_ ]?number|routing|ssn|social[-_ ]?security/i;
  function isCredentialField(el) {
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) return false;
    if (el.type === "password") return true;
    const hay = ["type", "autocomplete", "id", "name", "placeholder", "aria-label", "title"].map((a) => el.getAttribute(a) || "").join(" ");
    return CRED.test(hay);
  }
  function intersectsViewport(el) {
    const vw = window.visualViewport?.width ?? innerWidth, vh = window.visualViewport?.height ?? innerHeight;
    for (const r of el.getClientRects()) if (r.width > 0 && r.height > 0 && r.right > 0 && r.bottom > 0 && r.left < vw && r.top < vh) return true;
    return false;
  }
  var REF_LINE = /^(\s*)-\s.*\[ref=(e\d+|f\d+e\d+)\](:.*)?$/;
  function aria(args = {}) {
    const i = injected();
    const raw = i.ariaSnapshot(document.body, { mode: "ai" });
    resetRefsIfEngineChanged();
    const snap = lastSnapshot();
    const info = snap?.info;
    if (!info) return raw;
    const out = [];
    let dropBelow = null;
    for (const line of raw.split("\n")) {
      const indent = line.length - line.trimStart().length;
      if (dropBelow !== null) {
        if (indent > dropBelow) continue;
        dropBelow = null;
      }
      const m = REF_LINE.exec(line);
      if (!m) {
        out.push(line);
        continue;
      }
      const entry = info.get(m[2]);
      const el = entry?.element;
      const ref = el ? stableRefOf(el) : m[2];
      const rline = ref === m[2] ? line : line.replace("[ref=" + m[2] + "]", "[ref=" + ref + "]");
      if (args.viewport && el && !intersectsViewport(el)) {
        dropBelow = indent;
        continue;
      }
      if (el && m[3] && isCredentialField(el)) {
        out.push(rline.slice(0, rline.length - m[3].length) + ": <redacted>");
        continue;
      }
      out.push(rline);
    }
    const active = document.activeElement;
    const focusRef = active && active !== document.body ? ariaRefOf(active) : null;
    return out.join("\n") + (focusRef ? `
Focused: [ref=${focusRef}]` : "");
  }
  var describe = (el, i) => {
    const attrs = {};
    for (const a of ["id", "name", "type", "placeholder", "aria-label", "title", "href", "data-testid", "value"]) {
      const v = el.getAttribute(a);
      if (v) attrs[a] = a === "value" && isCredentialField(el) ? "<redacted>" : v.slice(0, 200);
    }
    return { nth: i, ref: ariaRefOf(el), selector: replaySelector(el), tag: el.tagName.toLowerCase(), role: roleOf(el), name: nameOf(el).slice(0, 120), text: text(el).slice(0, 120), attrs, visible: is(el, "visible"), enabled: stateOf(el, "enabled").received.startsWith("error:") ? null : is(el, "enabled"), editable: stateOf(el, "editable").received.startsWith("error:") ? null : is(el, "editable"), box: box(el) };
  };
  function find(args) {
    let usedSelector = args.selector;
    let matches = query(args.selector);
    if (!matches.length && args.fallback) {
      usedSelector = args.fallback;
      matches = query(args.fallback);
    }
    const visible_n = matches.filter((m) => is(m, "visible")).length;
    return { matches_n: matches.length, visible_n, selector: usedSelector, entries: matches.slice(0, Math.max(1, Math.min(args.limit, 100))).map(describe) };
  }
  function elementAt(args) {
    const el = document.elementFromPoint(args.x, args.y);
    if (!el) return { matches_n: 0, entries: [] };
    const chain = [];
    let n = el;
    while (n && n !== document.body && chain.length < 4) {
      chain.push(n);
      n = n.parentElement;
    }
    return { matches_n: chain.length, entries: chain.map(describe) };
  }
  var ANNOTATE_ID = "opencli-mcp-annotate";
  function annotate() {
    unannotate();
    const snap = lastSnapshot();
    if (!snap?.info) return 0;
    const layer = document.createElement("div");
    layer.id = ANNOTATE_ID;
    layer.setAttribute("style", "all:initial;position:fixed;inset:0;z-index:2147483645;pointer-events:none;font:11px/1 -apple-system,Segoe UI,Arial,sans-serif;");
    let count = 0;
    for (const [, v] of snap.info) {
      const el = v?.element;
      if (!el || !is(el, "visible") || !intersectsViewport(el)) continue;
      const r = el.getBoundingClientRect();
      const tag = document.createElement("span");
      tag.textContent = stableRefOf(el);
      tag.setAttribute("style", `position:absolute;left:${Math.max(0, r.left)}px;top:${Math.max(0, r.top - 12)}px;background:#1d4ed8;color:#fff;padding:1px 3px;border-radius:2px;white-space:nowrap;`);
      const outline = document.createElement("div");
      outline.setAttribute("style", `position:absolute;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;outline:1px solid rgba(29,78,216,.8);`);
      layer.append(outline, tag);
      if (++count >= 300) break;
    }
    document.documentElement.appendChild(layer);
    return count;
  }
  function unannotate() {
    document.getElementById(ANNOTATE_ID)?.remove();
  }
  function check(args) {
    const failed = [];
    const bodyText = (document.body?.innerText ?? document.body?.textContent ?? "").replace(/\s+/g, " ");
    if (args.text !== void 0 && !bodyText.includes(args.text)) failed.push(`text "${args.text}" not on the page`);
    if (args.notText !== void 0 && bodyText.includes(args.notText)) failed.push(`text "${args.notText}" still on the page`);
    if (args.url !== void 0 && !location.href.includes(args.url)) failed.push(`url ${location.href} does not include "${args.url}"`);
    if (args.title !== void 0 && !document.title.includes(args.title)) failed.push(`title "${document.title}" does not include "${args.title}"`);
    const locator = args.selector ?? (args.ref ? `aria-ref=${args.ref}` : void 0);
    if (locator !== void 0) {
      const els = query(locator);
      const wantVisible = args.visible !== false;
      if (!els.length) {
        if (wantVisible) failed.push(`${locator} matches nothing`);
      } else if (wantVisible && !els.some((e) => is(e, "visible"))) failed.push(`${locator} matches but none is visible`);
      else if (!wantVisible && els.some((e) => is(e, "visible"))) failed.push(`${locator} is still visible`);
    }
    return { ok: failed.length === 0, failed, url: location.href, title: document.title };
  }
  var api = { check, resolve, pointInfo, focus, readValue, fill, nativeSet, isChecked, select, caretToEnd, isFileInput, useAssociatedFileInput, clearActMark, settle, frameProbe, clearFrameMark, aria, find, elementAt, annotate, unannotate };
  globalThis[PAGE_GLOBAL] = api;
})();
