"use strict";
(() => {
  // extension/src/content/cursor.ts
  var ROOT_ID = "opencli-mcp-overlay-root";
  var host = null;
  var cursor = null;
  var keeper = null;
  var pos = { x: -100, y: -100 };
  var anim = null;
  function ensureOverlay() {
    if (host && document.documentElement.contains(host)) return cursor;
    host = document.createElement("div");
    host.id = ROOT_ID;
    host.setAttribute("style", "all:initial;position:fixed;inset:0;z-index:2147483646;pointer-events:none;");
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `.c{position:fixed;left:0;top:0;width:28px;height:32px;pointer-events:none;will-change:transform;filter:drop-shadow(0 1px 2px rgba(0,0,0,.35));transition:opacity .2s;opacity:0}.c.on{opacity:1}@media print{.c{display:none}}`;
    cursor = document.createElement("div");
    cursor.className = "c";
    const img = document.createElement("img");
    try {
      img.src = chrome.runtime.getURL("cursor.svg");
    } catch {
    }
    img.width = 28;
    img.height = 32;
    img.alt = "";
    cursor.appendChild(img);
    shadow.append(style, cursor);
    document.documentElement.appendChild(host);
    keeper = new MutationObserver(() => {
      if (host && !document.documentElement.contains(host)) document.documentElement.appendChild(host);
    });
    keeper.observe(document.documentElement, { childList: true });
    return cursor;
  }
  function moveTo(x, y, animate) {
    const el = ensureOverlay();
    el.classList.add("on");
    if (anim) cancelAnimationFrame(anim);
    const from = { ...pos };
    const dist = Math.hypot(x - from.x, y - from.y);
    const duration = !animate || from.x < 0 ? 0 : Math.min(600, 120 + dist * 0.6);
    const start = performance.now();
    if (duration === 0 || document.visibilityState !== "visible") {
      pos = { x, y };
      el.style.transform = `translate(${x - 2}px, ${y - 2}px)`;
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      const step = (now) => {
        const t = duration === 0 ? 1 : Math.min(1, (now - start) / duration);
        const e = 1 - Math.pow(1 - t, 3);
        pos = { x: from.x + (x - from.x) * e, y: from.y + (y - from.y) * e };
        el.style.transform = `translate(${pos.x - 2}px, ${pos.y - 2}px)`;
        if (t < 1) anim = requestAnimationFrame(step);
        else {
          anim = null;
          pos = { x, y };
          resolve();
        }
      };
      anim = requestAnimationFrame(step);
    });
  }
  function dispose() {
    keeper?.disconnect();
    keeper = null;
    if (anim) {
      cancelAnimationFrame(anim);
      anim = null;
    }
    host?.remove();
    host = null;
    cursor = null;
    pos = { x: -100, y: -100 };
  }
  function render(state) {
    if (!state) {
      dispose();
      return Promise.resolve({ arrived: false });
    }
    if (!state.visible) {
      if (cursor) cursor.classList.remove("on");
      pos = { x: state.x, y: state.y };
      return Promise.resolve({ arrived: false });
    }
    return moveTo(state.x, state.y, state.animate === true && document.visibilityState === "visible").then(() => ({ arrived: true, seq: state.seq }));
  }
  function alive() {
    try {
      return Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function pullState() {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage({ type: "opencli:cursor-state?" }).then((r) => {
        if (r && r.state !== void 0) void render(r.state ? { ...r.state, animate: false } : null);
      }).catch(() => {
      });
    } catch {
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "opencli:ping") {
      sendResponse({ ok: true });
      return false;
    }
    if (msg?.type === "opencli:cursor-state") {
      void render(msg.state ?? null).then(sendResponse);
      return true;
    }
    return false;
  });
  window.addEventListener("pageshow", pullState);
  pullState();
})();
